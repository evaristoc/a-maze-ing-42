from mazegen.maze_factory.cells import Cell
from mazegen.maze_solvers.base_solver import MazeSolver


class SinglePathSolver(MazeSolver):

    def solve(self) -> list[list[Cell]]:
        entry = self.maze.maze_entry_cell
        goal = self.maze.maze_exit_cell

        if entry is None or goal is None:
            return []

        start: Cell = entry  # widen type from EntryCell to Cell
        opposite_direction = {
            "north": "south", "east": "west",
            "south": "north", "west": "east"
        }

        stack: list[tuple[Cell, list[Cell]]] = [(start, [start])]
        visited: set[Cell] = {start}
        while stack:
            current, path = stack.pop()
            if (current.cell_position_x == goal.cell_position_x
                    and current.cell_position_y == goal.cell_position_y):
                if path is not None:
                    return [path]
            for neighbor, direction in (
                    self.maze.get_adjacent_cells_with_directions(current)):
                if not neighbor.is_walkable():
                    continue
                if neighbor in visited:
                    continue
                if neighbor is None:
                    continue
                direction = opposite_direction[direction]
                if neighbor.has_wall(direction):
                    continue
                visited.add(neighbor)
                stack.append((neighbor, path + [neighbor]))
        return []
