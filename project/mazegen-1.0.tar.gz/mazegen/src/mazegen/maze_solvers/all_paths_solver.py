from mazegen.maze_factory.cells import Cell
from mazegen.maze_solvers.base_solver import MazeSolver


class AllPathsSolver(MazeSolver):

    def solve(self) -> list[list[Cell]]:
        entry = self.maze.maze_entry_cell
        goal = self.maze.maze_exit_cell

        if entry is None or goal is None:
            return []

        start: Cell = entry  # widen type from EntryCell to Cell
        goal_cell: Cell = goal  # widen type from ExitCell to Cell
        all_paths: list[list[Cell]] = []
        opposite_direction = {
            "north": "south", "east": "west",
            "south": "north", "west": "east"
        }

        def dfs(
            current: Cell,
            path: list[Cell],
            visited: set[Cell]
        ) -> None:
            if (
                current.cell_position_x == goal_cell.cell_position_x
                and current.cell_position_y == goal_cell.cell_position_y
            ):
                all_paths.append(path.copy())
                return
            for neighbor, direction in (
                    self.maze.get_adjacent_cells_with_directions(current)):
                if neighbor is None or neighbor in visited:
                    continue
                if not neighbor.is_walkable():
                    continue
                opp = opposite_direction[direction]
                if neighbor.has_wall(opp):
                    continue
                visited.add(neighbor)
                path.append(neighbor)
                dfs(neighbor, path, visited)
                path.pop()
                visited.remove(neighbor)

        dfs(start, [start], {start})
        return all_paths

    @staticmethod
    def find_shortest_path(
        paths: list[list[Cell]]
    ) -> list[list[Cell]]:
        if not paths:
            return []
        shortest = min(paths, key=len)
        return [shortest]

    def solve_shortest(self) -> list[list[Cell]]:
        all_paths = self.solve()
        return self.find_shortest_path(all_paths)
