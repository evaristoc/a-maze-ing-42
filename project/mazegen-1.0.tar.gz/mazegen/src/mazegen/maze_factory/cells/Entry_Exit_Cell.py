from .Cell import Cell


class EntryCell(Cell):
    """
    Entry point of the maze.
    Must be on maze boundary.
    """

    def __init__(
        self, cell_position_x: int, cell_position_y: int
    ) -> None:
        super().__init__(cell_position_x, cell_position_y, 0b1111)

    def __repr__(self) -> str:
        return f"ENTRY({self.cell_position_x}, {self.cell_position_y})"

    def is_special_cell(self) -> bool:
        return True


class ExitCell(Cell):
    """
    Exit point of the maze.
    Must be different from entry.
    """

    def __init__(
        self, cell_position_x: int, cell_position_y: int
    ) -> None:
        super().__init__(cell_position_x, cell_position_y, 0b1111)

    def __repr__(self) -> str:
        return f"EXIT({self.cell_position_x}, {self.cell_position_y})"

    def is_special_cell(self) -> bool:
        return True
