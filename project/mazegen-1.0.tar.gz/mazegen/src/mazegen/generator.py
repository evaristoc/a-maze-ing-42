from typing import Any, Optional, Union

from mazegen.map import (
    convert_cell_path_to_directions,
    write_hexadecimal_map_to_file,
)
from mazegen.maze_factory import Cell, Maze
from mazegen.maze_solvers import ShortestPathSolver, SinglePathSolver


class MazeGenerator:
    def __init__(
        self,
        width: Optional[int] = 10,
        height: Optional[int] = 10,
        seed: Optional[int] = 0
    ):
        self.width = width
        self.height = height
        self.seed = seed
        self.maze_structure: Any = None
        self.solution: list[Cell] = []
        self.maze: Maze
        self.packed_solution: list[list[Cell]] = []

    def generate(
        self,
        perfect: bool = True,
        entry: tuple[int, int] = (0, 0),
        exit: tuple[int, int] = (0, 0)
    ) -> None:
        if self.width and self.height and self.seed:
            self.maze = Maze(self.width, self.height, self.seed)
        self.maze.place_fourty_two_glyph_at_maze_center()
        self.maze.place_entry_and_exit_cells(entry, exit)
        self.entry = entry
        self.exit = exit
        solver: Union[SinglePathSolver, ShortestPathSolver]
        if perfect:
            self.maze.generate_perfect_maze()
            solver = SinglePathSolver(self.maze)
        else:
            self.maze.generate_simple_maze()
            solver = ShortestPathSolver(self.maze)
        solution = solver.solve()
        self.packed_solution = solution
        self.solution = solution[0] if solution else []
        self.maze_structure = self.maze.two_dimensional_cell_grid

    def get_structure(self) -> Any:
        return self.maze_structure

    def get_solution(self) -> list[Cell]:
        return self.solution

    def get_directions(self) -> list[tuple[Cell, str]]:
        directions = convert_cell_path_to_directions(
            self.maze, self.solution
        )
        base = (
            self.packed_solution[0][1:-1] if self.packed_solution else []
        )
        return [(c, d) for c, d in zip(base, directions[1:])]

    def save(self, output_file: str) -> None:
        write_hexadecimal_map_to_file(
            self.maze, self.entry, self.exit,
            self.solution, output_file
        )
